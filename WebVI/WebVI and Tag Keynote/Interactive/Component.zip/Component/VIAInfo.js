//  via info  
NationalInstruments.HtmlVI.viName = '_%46unction%2Egvi';

//inputs: 
NationalInstruments.HtmlVI.inputDataItem = {};
NationalInstruments.HtmlVI.inputDataItem['di_39']='Boolean';
NationalInstruments.HtmlVI.inputDataItem['di_46']='Boolean';

//outputs:
NationalInstruments.HtmlVI.outputDataItem = {};
NationalInstruments.HtmlVI.outputDataItem['di_160']='Number';
NationalInstruments.HtmlVI.outputDataItem['di_154']='Number';
NationalInstruments.HtmlVI.outputDataItem['di_148']='Number';
NationalInstruments.HtmlVI.outputDataItem['di_608']='String';
NationalInstruments.HtmlVI.outputDataItem['di_26']='Array';