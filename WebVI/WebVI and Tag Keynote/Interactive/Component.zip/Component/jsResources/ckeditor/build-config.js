﻿/*
 Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
var CKBUILDER_CONFIG={skin:"moono",preset:"basic",ignore:".bender bender.js bender-err.log bender-out.log dev .DS_Store .gitattributes .gitignore gruntfile.js .idea .jscsrc .jshintignore .jshintrc .mailmap node_modules package.json README.md tests samples about contextmenu find floatingspace".split(" "),plugins:{autocorrect:1,basicstyles:1,clipboard:1,codemirror:1,colorbutton:1,enterkey:1,entities:1,font:1,htmlwriter:1,indentblock:1,indentlist:1,justify:1,link:1,list:1,magicline:1,onchange:1,sourcearea:1,
tab:1,table:1,tableresize:1,textselection:1,undo:1,video:1,widget:1,wysiwygarea:1},languages:{en:1}};